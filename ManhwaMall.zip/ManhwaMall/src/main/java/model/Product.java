package model;

import java.io.File;

import javax.servlet.http.Part;

import util.StringUtil;

public class Product {
    private int productId;
    private String productName;
    private String productGenre;
    private String productPrice;
    private String image;
    // Constructors
    public Product() {
    }

    public Product(int productId, String productName, String productGenre, String productPrice,Part imagePart) {
        this.productId = productId;
        this.productName = productName;
        this.productGenre = productGenre;
        this.productPrice = productPrice;
        this.image = getImageUrl(imagePart);
    }

    public Product(String productName, String productGenre, String productPrice) {
        this.productName = productName;
        this.productGenre = productGenre;
        this.productPrice = productPrice;
    }

    public Product(String productName, String productGenre, String productPrice, Part imagePart) {
    	this.productName = productName;
        this.productGenre = productGenre;
        this.productPrice = productPrice;
        this.image = getImageUrl(imagePart);
	}

	public Product(String productName2, String productGenre2, String productPrice2, String image2) {
		// TODO Auto-generated constructor stub
	}

	// Getters and setters
    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductGenre() {
        return productGenre;
    }

    public void setProductGenre(String productGenre) {
        this.productGenre = productGenre;
    }

    public String getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(String productPrice) {
        this.productPrice = productPrice;
    }

    
	public String getImageUrlFromPart() {
		return image;
	}
	
	public void setImageUrlFromPart(Part part) {
		this.image = getImageUrl(part);
	}
	
	public void setImageUrlFromDB(String imageUrl) {
		this.image = imageUrl;
	}
	
	private String getImageUrl(Part part) {
	    if (part == null) {
	        return "default.jpg"; // Return a default image URL or handle the null case accordingly
	    }

	    String savePath = StringUtil.IMAGE_DIR_SAVE_PATH_PRODUCT;
	    File fileSaveDir = new File(savePath);
	    String imageUrlFromPart = null;
	    if (!fileSaveDir.exists()) {
	        fileSaveDir.mkdir();
	    }
	    String contentDisp = part.getHeader("content-disposition");
	    String[] items = contentDisp.split(";");
	    for (String s : items) {
	        if (s.trim().startsWith("filename")) {
	            imageUrlFromPart = s.substring(s.indexOf("=") + 2, s.length() - 1);
	        }
	    }
	    if (imageUrlFromPart == null || imageUrlFromPart.isEmpty()) {
	        imageUrlFromPart = "download.jpg";
	    }
	    return imageUrlFromPart;
	}

	
    // toString method
    @Override
    public String toString() {
        return "Product [productId=" + productId + ", productName=" + productName + ", productGenre=" + productGenre
                + ", productPrice=" + productPrice + "]";
    }
}
