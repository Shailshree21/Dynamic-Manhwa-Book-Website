package controller.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import controller.servlets.RegisterServlet;
import model.LoginModel;
import model.UserModel;
import model.PasswordEncryptionWithAes;
import model.Product;
import util.StringUtil;

public class DbController {

	public static Connection getConnection() throws SQLException, ClassNotFoundException {

		// Load the JDBC driver class specified by the StringUtils.DRIVER_NAME constant
		Class.forName(StringUtil.DRIVER_NAME);

		// Create a connection to the database using the provided credentials
		return DriverManager.getConnection(StringUtil.LOCALHOST_URL, StringUtil.LOCALHOST_USERNAME,
				StringUtil.LOCALHOST_PASSWORD);
	}

	public int registerUser(UserModel register) {

		try {
			// Prepare a statement using the predefined query for student registration
			PreparedStatement stmt = getConnection().prepareStatement(StringUtil.QUERY_REGISTER_STUDENT);

			// Set the student information in the prepared statement
			stmt.setString(1, register.getUsername());
			stmt.setString(2, register.getEmail());
			stmt.setString(3, register.getPhoneNumber());
			stmt.setString(4, PasswordEncryptionWithAes.encrypt(register.getUsername(), register.getPassword()));
			stmt.setString(5, register.getImageUrlFromPart());

			// Execute the update statement and store the number of affected rows
			int result = stmt.executeUpdate();

			// Check if the update was successful (i.e., at least one row affected)
			if (result > 0) {
				return 1; // Registration successful
			} else {
				return 0; // Registration failed (no rows affected)
			}

		} catch (ClassNotFoundException | SQLException ex) {
			// Print the stack trace for debugging purposes
			ex.printStackTrace();
			return -1; // Internal error
		}
	}
	
	public int addProduct(Product product) {

		try {
			
			PreparedStatement stmt = getConnection().prepareStatement(StringUtil.QUERY_ADD_PRODUCT);

			// Set the student information in the prepared statement
			stmt.setString(1, product.getProductName());
			stmt.setString(2, product.getProductGenre());
			stmt.setString(3, product.getProductPrice());
			stmt.setString(4, product.getImageUrlFromPart());

			// Execute the update statement and store the number of affected rows
			int result = stmt.executeUpdate();

			// Check if the update was successful (i.e., at least one row affected)
			if (result > 0) {
				return 1; 
			} else {
				return 0; 
			}

		} catch (ClassNotFoundException | SQLException ex) {
			// Print the stack trace for debugging purposes
			ex.printStackTrace();
			return -1; // Internal error
		}
	}

	public int getUserLoginInfo(LoginModel loginModel) {
		try {
			// Prepare a statement using the predefined query for login check
			PreparedStatement st = getConnection().prepareStatement(StringUtil.QUERY_LOGIN_USER_CHECK);

			// Set the username in the first parameter of the prepared statement
			st.setString(1, loginModel.getUsername());

			// Execute the query and store the result set
			ResultSet result = st.executeQuery();

			// Check if there's a record returned from the query
			if (result.next()) {
				// Get the username, password, and role type from the database
				String userDb = result.getString(StringUtil.USERNAME);
				String passwordDb = result.getString(StringUtil.PASSWORD);
				//decrypt
				
				String decryptPassword =  PasswordEncryptionWithAes.decrypt(passwordDb, userDb);
				String roleTypeDb = result.getString("roleType");

				// Check if the username and password match the credentials from the database
				if (userDb.equals(loginModel.getUsername()) && decryptPassword.equals(loginModel.getPassword()))
				{
					// Check the role type
					if (roleTypeDb.equals("admin")) {
						// Return 1 for admin role
						return 1;
					} else if (roleTypeDb.equals("user")) {
						// Return 2 for user role
						return 2;
					} else {
						// Return 0 for other roles
						return 0;
					}
				} else {
					// Username or password mismatch, return -1
					return -1;
				}
			} else {
				// Username not found in the database, return -1
				return -2;
			}
		} catch (SQLException | ClassNotFoundException ex) {
			// Print the stack trace for debugging purposes
			ex.printStackTrace();
			// Return -2 to indicate an internal error
			return -3;
		}
	}

	public ArrayList<UserModel> getAllUsersInfo() {
		try {
			PreparedStatement stmt = getConnection().prepareStatement(StringUtil.QUERY_GET_ALL_USERS);
			ResultSet result = stmt.executeQuery();

			ArrayList<UserModel> user = new ArrayList<>();

			while (result.next()) {
				UserModel model = new UserModel();
				model.setUsername(result.getString("username"));
				model.setEmail(result.getString("email"));
				model.setPhoneNumber(result.getString("phoneNumber"));
				model.setImageUrlFromDB(result.getString("image"));

				user.add(model);
			}
			return user;
		} catch (SQLException | ClassNotFoundException ex) {
			ex.printStackTrace();
			return null;
		}
	}
	
	public ArrayList<Product> getAllProductInfo(){
	    try {
	        PreparedStatement stmt = getConnection().prepareStatement(StringUtil.QUERY_GET_ALL_PRODUCTS);
	        ResultSet result = stmt.executeQuery();

	        ArrayList<Product> product = new ArrayList<>();
	        
	        while (result.next()) {
	            Product model = new Product();
	            model.setProductId(result.getInt("productId"));
	            model.setProductName(result.getString("productName"));
	            model.setProductGenre(result.getString("productGenre"));
	            model.setProductPrice(result.getString("productPrice"));
	            model.setImageUrlFromDB(result.getString("image"));
	            
	            product.add(model);
	        }
	        return product;
	        
	    } catch (SQLException | ClassNotFoundException ex) {
	        ex.printStackTrace();
	        return null;
	    }
	}

    public UserModel getUserByUsername(String username) {
        UserModel user = null;
        ResultSet rs = null;
        
        try {
            PreparedStatement stmt = getConnection().prepareStatement("SELECT * FROM user_table WHERE userName = ?");
            
            stmt.setString(1, username);
            rs = stmt.executeQuery();
            
            if (rs.next()) {
                // Create a User object and populate its fields with data from the ResultSet
                user = new UserModel();
                user.setUsername(rs.getString("username"));
                user.setEmail(rs.getString("email"));
                user.setPhoneNumber(rs.getString("phoneNumber"));
                user.setImageUrlFromDB(rs.getString("image"));
                // Populate other fields as needed
            }
        } catch (SQLException | ClassNotFoundException ex) {
            ex.printStackTrace();
            // Handle database errors
        } 
        
        return user;
    }
    
    public ArrayList<Product> getProductByProductName() {
        Product products = null;
        ResultSet rs = null;
        
        try {
            PreparedStatement stmt = getConnection().prepareStatement("SELECT * FROM manhwa_table WHERE productName = ?");
            
            
            rs = stmt.executeQuery();
            
            ArrayList<Product> product = new ArrayList<>();
            while (rs.next()) {
                // Create a User object and populate its fields with data from the ResultSet
            	Product pr = new Product();
            	pr.setProductName(rs.getString("productName"));
            	pr.setProductGenre(rs.getString("productGenre"));
            	pr.setProductPrice(rs.getString("productPrice"));
            	pr.setImageUrlFromDB(rs.getString("image"));
                // Populate other fields as needed
            	product.add(pr);
            }
            return product;
            
        } catch (SQLException | ClassNotFoundException ex) {
            ex.printStackTrace();
            // Handle database errors
            return null;
        } 
        
        
    }
    
    public String editProfileDetails(UserModel model) {
			String message = "";
			try {
				
				PreparedStatement pst = getConnection().prepareStatement("UPDATE user_tablle\n"
						+ "SET username=?, email=?, phoneNumber=?, password=?, image=?\n"
						+ "WHERE username=?;");
				
				pst.setString(1,model.getUsername());
				pst.setString(2,model.getEmail());
				pst.setString(3,model.getPhoneNumber());
				pst.setString(4,model.getPassword());
				pst.setString(5,model.getImageUrlFromPart());
			
				int rows = pst.executeUpdate();
				if(rows >= 1) {
					message = "Successfully Added";
				}
					
			} catch (SQLException | ClassNotFoundException e) {
				System.out.println(e.getMessage());
				message = e.getMessage();
			}
			return message;	
		}
    
    public String editProductDetails(Product model) {
		String message = "";
		try {
			
			PreparedStatement pst = getConnection().prepareStatement("UPDATE manhwa_table\n"
					+ "SET productName=?, productGenre=?, productPrice=?, image=?\n"
					+ "WHERE username=?;");
			
			pst.setString(1,model.getProductName());
			pst.setString(2,model.getProductGenre());
			pst.setString(3,model.getProductPrice());
			pst.setString(4,model.getImageUrlFromPart());
		
			int rows = pst.executeUpdate();
			if(rows >= 1) {
				message = "Successfully Updated";
			}
				
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e.getMessage());
			message = e.getMessage();
		}
		return message;	
	}

	public int deleteUserInfo(String username) {
		try (Connection con = getConnection()) {
			PreparedStatement st = con.prepareStatement(StringUtil.QUERY_DELETE_USER);
			st.setString(1, username);
			return st.executeUpdate();
		} catch (SQLException | ClassNotFoundException ex) {
			ex.printStackTrace(); // Log the exception for debugging
			return -1;
		}
	}
	
	public int deleteProductInfo(String productName) {
		try (Connection con = getConnection()) {
			PreparedStatement st = con.prepareStatement(StringUtil.QUERY_DELETE_PRODUCT);
			st.setString(1, productName);
			return st.executeUpdate();
		} catch (SQLException | ClassNotFoundException ex) {
			ex.printStackTrace(); // Log the exception for debugging
			return -1;
		}
	}
	
	
	
	

}