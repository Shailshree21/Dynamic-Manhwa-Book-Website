package controller.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.database.DbController;
import model.Product;
import util.StringUtil;

/**
 * Servlet implementation class ModifyProductServlet
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/ModifyProductServlet" })
public class ModifyProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final DbController dbController;
   
    public ModifyProductServlet() {
    	this.dbController = new DbController();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String updateId = request.getParameter(StringUtil.UPDATE_ID);
		String deleteId = request.getParameter(StringUtil.DELETE_ID);

		if (updateId != null && !updateId.isEmpty()) {
			doPut(request, response);
		}
		if (deleteId != null && !deleteId.isEmpty()) {
			doDelete(request, response);
		}
	}
    
    @Override
	protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String productName = req.getParameter("productName");
		String productGenre = req.getParameter("productGenre");
		String productPrice = req.getParameter("productPrice");
		String image = req.getParameter("image");
		
		Product product = new Product(productName,productGenre,productPrice,image);
		String rows = dbController.editProductDetails(product);
		
		resp.sendRedirect(req.getContextPath() + StringUtil.PAGE_URL_PRODUCT_EDIT);
	}
    
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("delete triggered");
		
		if (dbController.deleteProductInfo(req.getParameter(StringUtil.DELETE_ID)) == 1) {
			req.setAttribute(StringUtil.MESSAGE_SUCCESS, StringUtil.MESSAGE_SUCCESS_DELETE);
			resp.sendRedirect(req.getContextPath() + StringUtil.PAGE_URL_CART);
		} else {
			req.setAttribute(StringUtil.MESSAGE_ERROR, StringUtil.MESSAGE_ERROR_DELETE);
			resp.sendRedirect(req.getContextPath() + StringUtil.PAGE_URL_CART);
		}
		
	}

	
	
	

}
