package controller.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import controller.database.DbController;
import model.UserModel;
import util.StringUtil;

/**
 * Servlet implementation class EditUser
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/EditUser" })
public class EditUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final DbController dbController;
	
    public EditUser() {
    	this.dbController = new DbController();
    }
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String email = request.getParameter(StringUtil.EMAIL);
        String phoneNumber = request.getParameter(StringUtil.PHONE_NUMBER);
        String username = request.getParameter(StringUtil.USERNAME);
        String password = request.getParameter(StringUtil.PASSWORD);
        Part imagePart = request.getPart("image");
        
        UserModel model = new UserModel(username, email, phoneNumber, password, imagePart);
        
		String message = dbController.editProfileDetails(model);
		if(message == "Successfully Added"){
			response.sendRedirect(request.getContextPath() + StringUtil.PAGE_URL_PROFILE+ "?success=true");
		}
	}

}
