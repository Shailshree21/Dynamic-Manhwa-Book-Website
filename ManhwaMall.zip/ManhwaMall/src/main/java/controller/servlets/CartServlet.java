package controller.servlets;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.database.DbController;
import model.Product;
import util.StringUtil;

/**
 * Servlet implementation class CartServlet
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/CartServlet" })
public class CartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	DbController controller = new DbController();
   
	
    public CartServlet() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, 
	IOException {
		
		
		ArrayList<Product> product = controller.getAllProductInfo();
		
		request.setAttribute("product_list",product);
		request.getRequestDispatcher(StringUtil.PAGE_URL_CART).forward(request, response); 
		
	}

	

}
