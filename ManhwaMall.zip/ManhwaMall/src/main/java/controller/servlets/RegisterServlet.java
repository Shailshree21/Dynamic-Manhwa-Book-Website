package controller.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import controller.database.DbController;
import model.UserModel;
import util.StringUtil;
import util.ValidationUtil;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/RegisterServlet" })
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
maxFileSize = 1024 * 1024 * 10, // 10MB
maxRequestSize = 1024 * 1024 * 50)

public class RegisterServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	private final DbController dbController;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
    	this.dbController = new DbController();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
	IOException {
        // Extract student information from request parameters

        String email = request.getParameter(StringUtil.EMAIL);
        String phoneNumber = request.getParameter(StringUtil.PHONE_NUMBER);
        String username = request.getParameter(StringUtil.USERNAME);
        String password = request.getParameter(StringUtil.PASSWORD);
        Part imagePart = request.getPart("image");
        
        // Implement data validation here (e.g., check for empty fields, email format, etc.)

        // Create a StudentModel object to hold student information
        UserModel model = new UserModel(username, email, phoneNumber, password, imagePart);
		
		// Implement data validation here (e.g., check for empty fields, email format,
		// etc.)
		if(!ValidationUtil.isTextOnly(username) ||
				!ValidationUtil.isAlphanumeric(username) ||
				!ValidationUtil.isEmail(email) ||
				!ValidationUtil.isNumbersOnly(phoneNumber)) {
			request.setAttribute(StringUtil.MESSAGE_ERROR, StringUtil.MESSAGE_ERROR_INCORRECT_DATA);
			request.getRequestDispatcher(StringUtil.PAGE_URL_REGISTER).forward(request, response);
		}        
        
        
        // Call DBController to register the student
        int result = dbController.registerUser(model);

        if (result == 1) {
        	// Get the image file name from the student object (assuming it was extracted earlier)
			String fileName = model.getImageUrlFromPart();

			// Check if a filename exists (not empty or null)
			if (!fileName.isEmpty() && fileName != null) {
			  // Construct the full image save path by combining the directory path and filename
			  String savePath = StringUtil.IMAGE_DIR_USER;
			  imagePart.write(savePath + fileName);  // Save the uploaded image to the specified path
			
			request.setAttribute(StringUtil.MESSAGE_SUCCESS, StringUtil.MESSAGE_SUCCESS_REGISTER);
			response.sendRedirect(request.getContextPath() + StringUtil.PAGE_URL_LOGIN+ "?success=true");
            
        } else if (result == 0) {
            request.setAttribute(StringUtil.MESSAGE_ERROR, StringUtil.MESSAGE_ERROR_REGISTER);
            request.getRequestDispatcher(StringUtil.PAGE_URL_REGISTER).forward(request, response);
        } else {
            request.setAttribute(StringUtil.MESSAGE_ERROR, StringUtil.MESSAGE_ERROR_SERVER);
            request.getRequestDispatcher(StringUtil.PAGE_URL_REGISTER).forward(request, response);
        }

        
	}

	}
}
