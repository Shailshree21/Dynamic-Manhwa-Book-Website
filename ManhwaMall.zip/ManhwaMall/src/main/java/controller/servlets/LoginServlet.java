package controller.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import controller.database.DbController;
import model.LoginModel;
import util.StringUtil;


/**
 * Servlet implementation class LoginServlet
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/LoginServlet" })
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final DbController dbController;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
    	this.dbController = new DbController();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, 
	IOException {
	    // Extract username and password from the request parameters
        String userName = request.getParameter(StringUtil.USERNAME);
        String password = request.getParameter(StringUtil.PASSWORD);
        
        
        // Create a LoginModel object to hold user credentials
        LoginModel loginModel = new LoginModel(userName, password);

        // Call DBController to validate login credentials
        int loginResult = dbController.getUserLoginInfo(loginModel);

     // Handle login results with appropriate messages and redirects
        if (loginResult == 1) {
            // Redirect admin user to index.jsp
            HttpSession userSession = request.getSession();
            userSession.setAttribute(StringUtil.USERNAME, userName);
            userSession.setMaxInactiveInterval(30*60);
            
            Cookie userCookie= new Cookie(StringUtil.USER, userName);
            userCookie.setMaxAge(30*60);
            response.addCookie(userCookie);
            
            // Login successful
            request.setAttribute(StringUtil.MESSAGE_SUCCESS, StringUtil.MESSAGE_SUCCESS_LOGIN);
            response.sendRedirect(request.getContextPath() + StringUtil.URL_INDEX);
         
            
        } else if (loginResult == 2) {
            // Redirect regular user to home.jsp
        	HttpSession userSession = request.getSession();
            userSession.setAttribute(StringUtil.USERNAME, userName);
            userSession.setMaxInactiveInterval(30*60);
            
            Cookie userCookie= new Cookie(StringUtil.USER, userName);
            userCookie.setMaxAge(30*60);
            response.addCookie(userCookie);
            
            // Login successful
            request.setAttribute(StringUtil.MESSAGE_SUCCESS, StringUtil.MESSAGE_SUCCESS_LOGIN);
            response.sendRedirect(request.getContextPath() + StringUtil.PAGE_URL_HOME);
  
            
        } else if (loginResult == 0) {
            // Username or password mismatch
            request.setAttribute(StringUtil.MESSAGE_ERROR, "Admin or user role not found!");
            request.setAttribute(StringUtil.USERNAME, userName);
            request.getRequestDispatcher(StringUtil.PAGE_URL_LOGIN).forward(request, response);
        } else if (loginResult == -1) {
            // Username or password mismatch
            request.setAttribute(StringUtil.MESSAGE_ERROR, StringUtil.MESSAGE_ERROR_LOGIN);
            request.setAttribute(StringUtil.USERNAME, userName);
            request.getRequestDispatcher(StringUtil.PAGE_URL_LOGIN).forward(request, response);
        } else if (loginResult == -2) {
            // Username not found
            request.setAttribute(StringUtil.MESSAGE_ERROR, StringUtil.MESSAGE_ERROR_CREATE_ACCOUNT);
            request.setAttribute(StringUtil.USERNAME, userName);
            request.getRequestDispatcher(StringUtil.PAGE_URL_LOGIN).forward(request, response);
        } else {
            // Internal server error
            request.setAttribute(StringUtil.MESSAGE_ERROR, StringUtil.MESSAGE_ERROR_SERVER);
            request.setAttribute(StringUtil.USERNAME, userName);
            request.getRequestDispatcher(StringUtil.PAGE_URL_LOGIN).forward(request, response);
        }
	}

}
