package controller.servlets;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.database.DbController;
import model.UserModel;
import util.StringUtil;

/**
 * Servlet implementation class profile
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/profile" })
public class ProfileServlet extends HttpServlet {
	
	private final DbController controller;
	
	
	public ProfileServlet() {
		controller = new DbController();
	}
  
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		ArrayList<UserModel> user = controller.getAllUsersInfo();
		
		request.setAttribute(StringUtil.USER_LISTS,user);
		request.getRequestDispatcher(StringUtil.PAGE_URL_PROFILE).forward(request, response); 
		
		
	}
}

