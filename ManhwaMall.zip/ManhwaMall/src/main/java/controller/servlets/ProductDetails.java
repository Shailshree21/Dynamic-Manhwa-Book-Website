package controller.servlets;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.database.DbController;
import model.Product;
import model.UserModel;
import util.StringUtil;

/**
 * Servlet implementation class ProductDetails
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/ProductDetails" })
public class ProductDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
	DbController controller = new DbController();   
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductDetails() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String data = request.getParameter(StringUtil.UPDATE_ID);
		
		//Product products = controller.getProductByProductName(data);
		
		
		
		//request.setAttribute("product_list",products);
		request.getRequestDispatcher(StringUtil.PAGE_URL_PRODUCT_EDIT).forward(request, response);
		
		
		
	}

	

}
