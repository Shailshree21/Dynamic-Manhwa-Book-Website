package controller.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.database.DbController;
import util.StringUtil;

/**
 * Servlet implementation class ModifyServlet
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/modifyUser" })
public class ModifyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final DbController dbController;
	
    public ModifyServlet() {
    	this.dbController = new DbController();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, 
	IOException {
		String updateId = request.getParameter(StringUtil.UPDATE_ID);
		String deleteId = request.getParameter(StringUtil.DELETE_ID);

		if (updateId != null && !updateId.isEmpty()) {
			doPut(request, response);
		}
		if (deleteId != null && !deleteId.isEmpty()) {
			doDelete(request, response);
		}
	}
	
	@Override
	protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, 
	IOException {

	}
	
	@Override
	protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, 
	IOException {
		System.out.println("delete triggered");
		if (dbController.deleteUserInfo(req.getParameter(StringUtil.DELETE_ID)) == 1) {
			req.setAttribute(StringUtil.MESSAGE_SUCCESS, StringUtil.MESSAGE_SUCCESS_DELETE);
			resp.sendRedirect(req.getContextPath() + StringUtil.URL_INDEX);
		} else {
			req.setAttribute(StringUtil.MESSAGE_ERROR, StringUtil.MESSAGE_ERROR_DELETE);
			resp.sendRedirect(req.getContextPath() + StringUtil.URL_INDEX);
		}
		
	}

}
